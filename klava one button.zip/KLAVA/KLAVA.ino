#include <Keypad.h> // подключаем библиотеку Keypad
 
const byte ROWS = 4; // 4 строки
const byte COLS = 4; // 4 столбца
 
// определим символы для кнопок
char hexaKeys[ROWS][COLS] = {
  {'0','1','2','3'},
  {'4','5','6','7'},
  {'8','9','A','B'},
  {'C','D','E','F'}
};
 
byte rowPins[ROWS] = {6, 7, 8, 9}; // цифровые выводы строк 
byte colPins[COLS] = {5, 4, 3, 2}; // цифровые выводы столбцов 
// используем класс библиотеки
Keypad customKeypad = Keypad(makeKeymap(hexaKeys), colPins, rowPins, COLS, ROWS);  
 
void setup(){
  Serial.begin(9600);
}   
 
void loop(){
  // вывод в монитор порта значения кнопки
  char customKey = customKeypad.getKey(); 
  if (customKey){
    Serial.println(customKey);
  }
}
